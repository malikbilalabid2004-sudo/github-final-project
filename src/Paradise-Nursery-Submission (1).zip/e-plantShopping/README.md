# Paradise Nursery

A three-view houseplant shop built with React and Redux Toolkit. Browse the
catalog, add plants to a cart, and adjust quantities before checkout.

> **Repo name matters for grading.** The Coursera AI grader for this
> assignment checks for a repository literally named `e-plantShopping`.
> Create/rename your GitHub repo to exactly that before submitting, and push
> this project into it.

**Views** (toggled with React state in `App.jsx` — no router)
- **Landing** — company name, background image, About Us copy, and a
  "Get Started" button that reveals the catalog.
- **Product list** — the catalog, organized into three categories, each
  plant with a thumbnail, name, price, and an Add to Cart button that
  disables itself once added.
- **Cart** — every item in the cart with quantity controls, a remove
  button, running totals, and checkout / continue shopping actions.

## Tech stack

- React 19 + Vite
- Redux Toolkit + React Redux (`src/redux/CartSlice.jsx` holds all cart
  state, with `addItem`, `removeItem`, and `updateQuantity` reducers)
- Plain CSS, no UI framework — all plant art is hand-built inline SVG, so
  there are no external image dependencies to break after deployment

## Project structure

```
src/
  App.jsx                 Landing page markup + view state (showProductList / showCart)
  App.css                 App-wide styling, including the .background-image class
  components/
    Header.jsx             Nav bar shown on the product and cart views, with live cart count
    AboutUs.jsx             Company copy (div.about-us-container) used on the landing page
    ProductList.jsx         Catalog grouped by category
    CartItem.jsx            Cart view: calculateTotalAmount, quantities, checkout alert
    PlantArt.jsx             Reusable inline-SVG plant illustrations
  redux/
    CartSlice.jsx            addItem / removeItem / updateQuantity reducers + selectors
    store.js                 Store setup
  data/
    plants.js                Catalog data (9 plants across 3 categories)
  assets/
    hero-bg.svg               Landing page background image
```

## Running locally

```bash
npm install
npm run dev
```

Then open the printed local URL (typically `http://localhost:5173`).

## Building

```bash
npm run build
npm run preview   # serve the production build locally to double-check it
```

## Deploying to GitHub Pages

1. Push this project to a public GitHub repository named `e-plantShopping`.
2. `vite.config.js` already sets `base: '/e-plantShopping/'` to match. If you
   use a different repo name, update that line to match it exactly.
3. Install and deploy:
   ```bash
   npm run deploy
   ```
   This builds the app and pushes `dist/` to a `gh-pages` branch using the
   `gh-pages` package (already listed in `devDependencies`).
4. In your repo's **Settings → Pages**, set the source to the `gh-pages`
   branch (root). Your site will be live at
   `https://<your-username>.github.io/e-plantShopping/`.

If you're on Windows/PowerShell, the same commands work as-is — no shell
scripts are used anywhere in this project.
