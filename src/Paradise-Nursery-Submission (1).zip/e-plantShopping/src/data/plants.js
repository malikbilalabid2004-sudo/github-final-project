// Catalog data for Paradise Nursery.
// Three categories with six unique plants in each category.

export const categories = [
  {
    id: 'air-purifying',
    name: 'Air-Purifying Plants',
    blurb: 'Quiet workers that filter the room while they grow.',
    plants: [
      { id: 'snake-plant', name: 'Snake Plant', price: 24, description: 'Upright, architectural, and famously hard to kill.', art: { variant: 'blade', leaf: '#3C6B48', dark: '#21402C' } },
      { id: 'peace-lily', name: 'Peace Lily', price: 28, description: 'Glossy leaves and pale blooms; tells you when it is thirsty.', art: { variant: 'leafy', leaf: '#4C7A56', dark: '#2C5138' } },
      { id: 'areca-palm', name: 'Areca Palm', price: 36, description: 'Feathery fronds that bring a courtyard indoors.', art: { variant: 'palm', leaf: '#5C8A63', dark: '#2C5138' } },
      { id: 'spider-plant', name: 'Spider Plant', price: 20, description: 'Arching striped leaves and easy-going growth.', art: { variant: 'leafy', leaf: '#7FA485', dark: '#4C7A56' } },
      { id: 'rubber-plant', name: 'Rubber Plant', price: 32, description: 'Broad glossy leaves with a bold upright silhouette.', art: { variant: 'leafy', leaf: '#3C6B48', dark: '#21402C' } },
      { id: 'boston-fern', name: 'Boston Fern', price: 26, description: 'Soft feathery fronds for a lush, classic look.', art: { variant: 'palm', leaf: '#4C7A56', dark: '#21402C' } },
    ],
  },
  {
    id: 'succulents-cacti',
    name: 'Succulents & Cacti',
    blurb: 'Low-water, high-character plants for sunny sills.',
    plants: [
      { id: 'echeveria', name: 'Echeveria', price: 16, description: 'A tidy rosette in dusty blue-green.', art: { variant: 'rosette', leaf: '#7FA485', dark: '#4C7A56' } },
      { id: 'barrel-cactus', name: 'Barrel Cactus', price: 19, description: 'Round, ribbed, and slow to change its mind.', art: { variant: 'barrel', leaf: '#5C8A63', dark: '#2C5138' } },
      { id: 'jade-plant', name: 'Jade Plant', price: 22, description: 'Coin-shaped leaves on woody little branches.', art: { variant: 'jade', leaf: '#5C8A63', dark: '#2C5138' } },
      { id: 'aloe-vera', name: 'Aloe Vera', price: 18, description: 'Spiky sculptural leaves with a sunny-sill personality.', art: { variant: 'blade', leaf: '#5C8A63', dark: '#2C5138' } },
      { id: 'haworthia', name: 'Haworthia', price: 17, description: 'Compact striped leaves that stay neat and cheerful.', art: { variant: 'rosette', leaf: '#4C7A56', dark: '#2C5138' } },
      { id: 'zebra-cactus', name: 'Zebra Cactus', price: 21, description: 'Small ridged leaves with distinctive white markings.', art: { variant: 'barrel', leaf: '#7FA485', dark: '#4C7A56' } },
    ],
  },
  {
    id: 'flowering',
    name: 'Flowering Plants',
    blurb: 'A little color, without much fuss.',
    plants: [
      { id: 'african-violet', name: 'African Violet', price: 15, description: 'Velvety leaves and small purple blooms.', art: { variant: 'flower', leaf: '#4C7A56', dark: '#2C5138', petal: '#8C5FB0', shape: 'round' } },
      { id: 'anthurium', name: 'Anthurium', price: 27, description: 'Waxy heart-shaped leaves under a bright bloom.', art: { variant: 'flower', leaf: '#3C6B48', dark: '#21402C', petal: '#B8394A', shape: 'heart' } },
      { id: 'begonia', name: 'Begonia', price: 18, description: 'Patterned leaves and clusters of soft pink flowers.', art: { variant: 'flower', leaf: '#5C8A63', dark: '#3C6B48', petal: '#D97AA0', shape: 'oval' } },
      { id: 'orchid', name: 'Orchid', price: 34, description: 'Elegant blooms that add a refined pop of color.', art: { variant: 'flower', leaf: '#4C7A56', dark: '#2C5138', petal: '#B07CC6', shape: 'oval' } },
      { id: 'geranium', name: 'Geranium', price: 23, description: 'Cheerful clustered flowers and rounded leaves.', art: { variant: 'flower', leaf: '#3C6B48', dark: '#21402C', petal: '#D95F75', shape: 'round' } },
      { id: 'hibiscus', name: 'Hibiscus', price: 29, description: 'Large colorful flowers for a bright indoor corner.', art: { variant: 'flower', leaf: '#5C8A63', dark: '#2C5138', petal: '#E58B5B', shape: 'round' } },
    ],
  },
];

export const allPlants = categories.flatMap((category) =>
  category.plants.map((plant) => ({ ...plant, category: category.name }))
);
